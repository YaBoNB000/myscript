-- ProfileService (ModuleScript)
-- ReplicatedStorage > devv > vendor
-- Original

local v_u_1 = {
	["AutoSaveProfiles"] = 30,
	["RobloxWriteCooldown"] = 7,
	["ForceLoadMaxSteps"] = 8,
	["AssumeDeadSessionLock"] = 1800,
	["IssueCountForCriticalState"] = 5,
	["IssueLast"] = 120,
	["CriticalStateLast"] = 120,
	["MetaTagsUpdatedValues"] = {
		["ProfileCreateTime"] = true,
		["SessionLoadCount"] = true,
		["ActiveSession"] = true,
		["ForceLoadSession"] = true,
		["LastUpdate"] = true
	}
}
local v2 = {}
local v_u_3 = nil
local function v_u_6(p4, ...)
	-- upvalues: (ref) v_u_3
	local v5 = v_u_3
	v_u_3 = nil
	p4(...)
	v_u_3 = v5
end
local function v_u_7(...)
	-- upvalues: (copy) v_u_6
	v_u_6(...)
	while true do
		v_u_6(coroutine.yield())
	end
end
local v_u_8 = {}
v_u_8.__index = v_u_8
function v_u_8.Disconnect(p9)
	-- upvalues: (ref) v_u_3, (copy) v_u_7
	if p9._is_connected ~= false then
		p9._is_connected = false
		local v10 = p9._script_signal
		v10._listener_count = v10._listener_count - 1
		if p9._script_signal._head == p9 then
			p9._script_signal._head = p9._next
		else
			local v11 = p9._script_signal._head
			while v11 ~= nil and v11._next ~= p9 do
				v11 = v11._next
			end
			if v11 ~= nil then
				v11._next = p9._next
			end
		end
		if p9._disconnect_listener ~= nil then
			if not v_u_3 then
				v_u_3 = coroutine.create(v_u_7)
			end
			task.spawn(v_u_3, p9._disconnect_listener, p9._disconnect_param)
			p9._disconnect_listener = nil
		end
	end
end
local v_u_12 = {}
v_u_12.__index = v_u_12
function v_u_12.Connect(p13, p14, p15, p16)
	-- upvalues: (copy) v_u_8
	local v17 = {
		["_listener"] = p14,
		["_script_signal"] = p13,
		["_disconnect_listener"] = p15,
		["_disconnect_param"] = p16,
		["_next"] = p13._head,
		["_is_connected"] = true
	}
	local v18 = v_u_8
	setmetatable(v17, v18)
	p13._head = v17
	p13._listener_count = p13._listener_count + 1
	return v17
end
function v_u_12.GetListenerCount(p19)
	return p19._listener_count
end
function v_u_12.Fire(p20, ...)
	-- upvalues: (ref) v_u_3, (copy) v_u_7
	local v21 = p20._head
	while v21 ~= nil do
		if v21._is_connected == true then
			if not v_u_3 then
				v_u_3 = coroutine.create(v_u_7)
			end
			task.spawn(v_u_3, v21._listener, ...)
		end
		v21 = v21._next
	end
end
function v_u_12.FireUntil(p22, p23, ...)
	local v24 = p22._head
	while v24 ~= nil do
		if v24._is_connected == true then
			v24._listener(...)
			if p23() ~= true then
				return
			end
		end
		v24 = v24._next
	end
end
function v2.NewScriptSignal()
	-- upvalues: (copy) v_u_12
	return {
		["_head"] = nil,
		["_listener_count"] = 0,
		["Connect"] = v_u_12.Connect,
		["GetListenerCount"] = v_u_12.GetListenerCount,
		["Fire"] = v_u_12.Fire,
		["FireUntil"] = v_u_12.FireUntil
	}
end
local v_u_27 = {
	["NewScriptSignal"] = v2.NewScriptSignal,
	["ConnectToOnClose"] = function(p25, p26)
		if game:GetService("RunService"):IsStudio() == false or p26 == true then
			game:BindToClose(p25)
		end
	end
}
local v_u_28 = {
	["ServiceLocked"] = false,
	["IssueSignal"] = v_u_27.NewScriptSignal(),
	["CorruptionSignal"] = v_u_27.NewScriptSignal(),
	["CriticalState"] = false,
	["CriticalStateSignal"] = v_u_27.NewScriptSignal(),
	["ServiceIssueCount"] = 0,
	["_active_profile_stores"] = {},
	["_auto_save_list"] = {},
	["_issue_queue"] = {},
	["_critical_state_start"] = 0,
	["_mock_data_store"] = {},
	["_user_mock_data_store"] = {},
	["_use_mock_data_store"] = false
}
local v_u_29 = v_u_28._active_profile_stores
local v_u_30 = v_u_28._auto_save_list
local v_u_31 = v_u_28._issue_queue
local v_u_32 = game:GetService("DataStoreService")
local v_u_33 = game:GetService("RunService")
local v_u_34 = game.PlaceId
local v_u_35 = game.JobId
local v_u_36 = 1
local v_u_37 = os.clock()
local v_u_38 = 0
local v_u_39 = 0
local v_u_40 = 0
local v_u_41 = 0
local v42 = v_u_33:IsStudio()
local v_u_43 = false
local v_u_44 = false
local v_u_45 = v_u_28._mock_data_store
local v_u_46 = v_u_28._user_mock_data_store
local v_u_47 = {}
local v_u_48 = {}
local function v_u_53(p49)
	-- upvalues: (copy) v_u_53
	local v50 = {}
	for v51, v52 in pairs(p49) do
		if type(v52) == "table" then
			v50[v51] = v_u_53(v52)
		else
			v50[v51] = v52
		end
	end
	return v50
end
local function v_u_59(p54, p55)
	-- upvalues: (copy) v_u_53, (copy) v_u_59
	for v56, v57 in pairs(p55) do
		if type(v56) == "string" then
			if p54[v56] == nil then
				if type(v57) == "table" then
					p54[v56] = v_u_53(v57)
				else
					p54[v56] = v57
				end
			else
				local v58 = p54[v56]
				if type(v58) == "table" and type(v57) == "table" then
					v_u_59(p54[v56], v57)
				end
			end
		end
	end
end
local function v_u_63(p60, p61, p62)
	return string.format("[Store:\"%s\";%sKey:\"%s\"]", p60, p61 == nil and "" or (string.format("Scope:\"%s\";", p61) or ""), p62)
end
local function v_u_70(p_u_64, p_u_65)
	-- upvalues: (copy) v_u_48, (copy) v_u_33, (copy) v_u_1
	if v_u_48[p_u_64] ~= nil then
		if v_u_48[p_u_64][p_u_65] == nil then
			if next(v_u_48[p_u_64]) == nil then
				v_u_48[p_u_64] = nil
			end
		else
			local v_u_66 = v_u_48[p_u_64][p_u_65]
			local v_u_67 = v_u_66.Queue
			if v_u_66.CleanupJob == nil then
				v_u_66.CleanupJob = v_u_33.Heartbeat:Connect(function()
					-- upvalues: (copy) v_u_66, (ref) v_u_1, (copy) v_u_67, (copy) p_u_64, (copy) p_u_65, (ref) v_u_48
					if os.clock() - v_u_66.LastWrite > v_u_1.RobloxWriteCooldown and #v_u_67 == 0 then
						v_u_66.CleanupJob:Disconnect()
						local v68 = p_u_64
						local v69 = p_u_65
						if v_u_48[v68] ~= nil then
							v_u_48[v68][v69] = nil
							if next(v_u_48[v68]) == nil then
								v_u_48[v68] = nil
							end
						end
					end
				end)
				return
			end
		end
	end
end
local function v_u_76(p71, p72, p73)
	-- upvalues: (copy) v_u_48, (copy) v_u_1
	if v_u_48[p72] == nil then
		v_u_48[p72] = {}
	end
	if v_u_48[p72][p73] == nil then
		v_u_48[p72][p73] = {
			["LastWrite"] = 0,
			["Queue"] = {},
			["CleanupJob"] = nil
		}
	end
	local v74 = v_u_48[p72][p73]
	local v75 = v74.Queue
	if v74.CleanupJob ~= nil then
		v74.CleanupJob:Disconnect()
		v74.CleanupJob = nil
	end
	if os.clock() - v74.LastWrite > v_u_1.RobloxWriteCooldown and #v75 == 0 then
		v74.LastWrite = os.clock()
		return p71()
	end
	table.insert(v75, p71)
	while os.clock() - v74.LastWrite <= v_u_1.RobloxWriteCooldown or v75[1] ~= p71 do
		task.wait()
	end
	table.remove(v75, 1)
	v74.LastWrite = os.clock()
	return p71()
end
local function v_u_83(p77, p78, p79, p80)
	-- upvalues: (copy) v_u_31, (copy) v_u_28
	warn("[ProfileService]: DataStore API error " .. string.format("[Store:\"%s\";%sKey:\"%s\"]", p78, p79 == nil and "" or (string.format("Scope:\"%s\";", p79) or ""), p80) .. " - \"" .. tostring(p77) .. "\"")
	local v81 = v_u_31
	local v82 = os.clock
	table.insert(v81, v82())
	v_u_28.IssueSignal:Fire(tostring(p77), p78, p80)
end
local function v_u_89(p84)
	-- upvalues: (copy) v_u_53
	local v85 = p84.VersionId or 0
	local v86 = tostring(v85)
	local v_u_87 = p84.MetaData or {}
	local v_u_88 = p84.UserIds or {}
	return {
		["CreatedTime"] = p84.CreatedTime,
		["UpdatedTime"] = p84.UpdatedTime,
		["Version"] = string.rep("0", 16) .. "." .. string.rep("0", 10 - string.len(v86)) .. v86 .. "." .. string.rep("0", 16) .. ".01",
		["GetMetadata"] = function()
			-- upvalues: (ref) v_u_53, (copy) v_u_87
			return v_u_53(v_u_87)
		end,
		["GetUserIds"] = function()
			-- upvalues: (ref) v_u_53, (copy) v_u_88
			return v_u_53(v_u_88)
		end
	}
end
local function v_u_107(p90, p91, p92, p93, p94)
	-- upvalues: (copy) v_u_89, (copy) v_u_53
	local v95 = p90[p91]
	if v95 == nil then
		v95 = {}
		p90[p91] = v95
	end
	local v96 = os.time() * 1000
	local v97 = math.floor(v96)
	local v98 = v95[p92]
	local v99
	if v98 == nil then
		v99 = true
		if p94 ~= true then
			v98 = {
				["Data"] = nil,
				["CreatedTime"] = v97,
				["UpdatedTime"] = v97,
				["VersionId"] = 0,
				["UserIds"] = {},
				["MetaData"] = {}
			}
			v95[p92] = v98
		end
	else
		v99 = false
	end
	local v100
	if v99 == false then
		v100 = v_u_89(v98) or nil
	else
		v100 = nil
	end
	local v101
	if v98 then
		v101 = v98.Data
	else
		v101 = v98
	end
	local v102, v103, v104 = p93(v101, v100)
	if v102 == nil then
		return nil
	end
	if v98 ~= nil and p94 ~= true then
		v98.Data = v102
		v98.UserIds = v_u_53(v103 or {})
		v98.MetaData = v_u_53(v104 or {})
		v98.VersionId = v98.VersionId + 1
		v98.UpdatedTime = v97
	end
	local v105 = v_u_53(v102)
	local v106
	if v98 == nil then
		v106 = nil
	else
		v106 = v_u_89(v98) or nil
	end
	return v105, v106
end
local function v_u_142(p_u_108, p_u_109, p_u_110, p_u_111, p_u_112, p_u_113)
	-- upvalues: (copy) v_u_107, (copy) v_u_46, (ref) v_u_44, (copy) v_u_45, (copy) v_u_76, (copy) v_u_28, (copy) v_u_83
	local v_u_114 = nil
	local v_u_115 = nil
	local v137, v138 = pcall(function()
		-- upvalues: (copy) p_u_110, (copy) p_u_111, (ref) v_u_114, (ref) v_u_115, (ref) v_u_107, (ref) v_u_46, (copy) p_u_108, (copy) p_u_109, (copy) p_u_112, (ref) v_u_44, (ref) v_u_45, (ref) v_u_76, (copy) p_u_113
		local function v_u_124(p116)
			-- upvalues: (ref) p_u_110
			local v117 = false
			local v118 = false
			local v119 = {
				0,
				{}
			}
			if p116 == nil then
				v117 = true
			elseif type(p116) ~= "table" then
				v117 = true
				v118 = true
			end
			if type(p116) == "table" then
				local v120 = p116.Data
				if type(v120) == "table" then
					local v121 = p116.MetaData
					if type(v121) == "table" then
						local v122 = p116.GlobalUpdates
						if type(v122) ~= "table" then
							goto l8
						end
						p116.WasCorrupted = false
						v119 = p116.GlobalUpdates
						if p_u_110.ExistingProfileHandle ~= nil then
							p_u_110.ExistingProfileHandle(p116)
						end
						goto l6
					end
				end
				::l8::
				if p116.Data == nil and p116.MetaData == nil then
					local v123 = p116.GlobalUpdates
					if type(v123) == "table" then
						p116.WasCorrupted = false
						v119 = p116.GlobalUpdates or v119
						v117 = true
					else
						v117 = true
						v118 = true
					end
				else
					v117 = true
					v118 = true
				end
				goto l6
			else
				::l6::
				if v117 == true then
					p116 = {
						["GlobalUpdates"] = v119
					}
					if p_u_110.MissingProfileHandle ~= nil then
						p_u_110.MissingProfileHandle(p116)
					end
				end
				if p_u_110.EditProfile ~= nil then
					p_u_110.EditProfile(p116)
				end
				if v118 == true then
					p116.WasCorrupted = true
				end
				return p116, p116.UserIds, p116.RobloxMetaData
			end
		end
		if p_u_111 == true then
			local v125, v126 = v_u_107(v_u_46, p_u_108._profile_store_lookup, p_u_109, v_u_124, p_u_112)
			v_u_114 = v125
			v_u_115 = v126
			task.wait()
			return
		elseif v_u_44 == true then
			local v127, v128 = v_u_107(v_u_45, p_u_108._profile_store_lookup, p_u_109, v_u_124, p_u_112)
			v_u_114 = v127
			v_u_115 = v128
			task.wait()
		else
			local v135, v136 = v_u_76(function()
				-- upvalues: (ref) p_u_112, (ref) p_u_113, (ref) p_u_108, (ref) p_u_109, (copy) v_u_124
				if p_u_112 ~= true then
					return p_u_108._global_data_store:UpdateAsync(p_u_109, v_u_124)
				end
				local v_u_129 = nil
				local v_u_130 = nil
				if p_u_113 == nil then
					v_u_129, v_u_130 = p_u_108._global_data_store:GetAsync(p_u_109)
				else
					local v133, v134 = pcall(function()
						-- upvalues: (ref) v_u_129, (ref) v_u_130, (ref) p_u_108, (ref) p_u_109, (ref) p_u_113
						local v131, v132 = p_u_108._global_data_store:GetVersionAsync(p_u_109, p_u_113)
						v_u_129 = v131
						v_u_130 = v132
					end)
					if v133 == false and (type(v134) == "string" and string.find(v134, "not valid") ~= nil) then
						warn("[ProfileService]: Passed version argument is not valid; Traceback:\n" .. debug.traceback())
					end
				end
				return v_u_124(v_u_129), v_u_130
			end, p_u_108._profile_store_lookup, p_u_109)
			v_u_114 = v135
			v_u_115 = v136
		end
	end)
	if v137 == true then
		local v139 = v_u_114
		if type(v139) == "table" then
			if v_u_114.WasCorrupted == true and p_u_112 ~= true then
				local v140 = p_u_108._profile_store_name
				local v141 = p_u_108._profile_store_scope
				warn("[ProfileService]: Resolved profile corruption " .. string.format("[Store:\"%s\";%sKey:\"%s\"]", v140, v141 == nil and "" or (string.format("Scope:\"%s\";", v141) or ""), p_u_109))
				v_u_28.CorruptionSignal:Fire(v140, p_u_109)
			end
			return v_u_114, v_u_115
		end
	end
	v_u_83((v138 == nil or not v138) and "Undefined error" or v138, p_u_108._profile_store_name, p_u_108._profile_store_scope, p_u_109)
	return nil
end
local function v_u_150(p143)
	-- upvalues: (copy) v_u_29, (copy) v_u_30, (ref) v_u_36
	local v144 = p143._profile_store;
	(p143._is_user_mock == true and v144._mock_loaded_profiles or v144._loaded_profiles)[p143._profile_key] = nil
	if next(v144._loaded_profiles) == nil and next(v144._mock_loaded_profiles) == nil then
		local v145 = table.find(v_u_29, v144)
		if v145 ~= nil then
			table.remove(v_u_29, v145)
		end
	end
	local v146 = table.find(v_u_30, p143)
	if v146 ~= nil then
		table.remove(v_u_30, v146)
		if v146 < v_u_36 then
			v_u_36 = v_u_36 - 1
		end
		if v_u_30[v_u_36] == nil then
			v_u_36 = 1
		end
	end
	local v147 = p143.MetaData.ActiveSession
	local v148, v149
	if v147 == nil then
		v148 = nil
		v149 = nil
	else
		v148 = v147[1]
		v149 = v147[2]
	end
	p143._release_listeners:Fire(v148, v149)
end
local function v_u_164(p151, p152, p153)
	local v154 = p151.GlobalUpdates
	local v155 = v154._pending_update_lock
	local v_u_156 = v154._pending_update_clear
	for _, v_u_157 in ipairs(p153[2]) do
		local v158 = nil
		for _, v159 in ipairs(p152[2]) do
			if v159[1] == v_u_157[1] then
				v158 = v159
				break
			end
		end
		if (v158 == nil or (v_u_157[2] > v158[2] or v_u_157[3] ~= v158[3])) == true then
			if v_u_157[3] == false then
				local v160 = false
				for _, v161 in ipairs(v155) do
					if v_u_157[1] == v161 then
						v160 = true
						break
					end
				end
				if v160 == false then
					v154._new_active_update_listeners:Fire(v_u_157[1], v_u_157[4])
				end
			end
			if v_u_157[3] == true then
				local v162 = false
				for _, v163 in ipairs(v_u_156) do
					if v_u_157[1] == v163 then
						v162 = true
						break
					end
				end
				if v162 == false then
					v154._new_locked_update_listeners:FireUntil(function()
						-- upvalues: (copy) v_u_156, (copy) v_u_157
						return table.find(v_u_156, v_u_157[1]) == nil
					end, v_u_157[1], v_u_157[4])
				end
			end
		end
	end
end
local function v_u_202(p_u_165, p_u_166, p_u_167)
	-- upvalues: (copy) v_u_28, (copy) v_u_150, (ref) v_u_40, (copy) v_u_142, (copy) v_u_34, (copy) v_u_35, (copy) v_u_1, (copy) v_u_164, (copy) v_u_70
	local v168 = p_u_165.Data
	if type(v168) ~= "table" then
		local v169 = p_u_165._profile_store._profile_store_name
		local v170 = p_u_165._profile_store._profile_store_scope
		local v171 = p_u_165._profile_key
		warn("[ProfileService]: Resolved profile corruption " .. string.format("[Store:\"%s\";%sKey:\"%s\"]", v169, v170 == nil and "" or (string.format("Scope:\"%s\";", v170) or ""), v171))
		v_u_28.CorruptionSignal:Fire(v169, v171)
		error("[ProfileService]: PROFILE DATA CORRUPTED DURING RUNTIME! Profile: " .. p_u_165:Identify())
	end
	if p_u_166 == true and p_u_167 ~= true then
		v_u_150(p_u_165)
	end
	v_u_40 = v_u_40 + 1
	local v_u_172 = p_u_165.MetaData.SessionLoadCount
	local v173 = true
	while v173 == true do
		if p_u_166 ~= true then
			v173 = false
		end
		local v189 = {
			["ExistingProfileHandle"] = nil,
			["MissingProfileHandle"] = nil,
			["EditProfile"] = function(p174)
				-- upvalues: (copy) p_u_167, (ref) v_u_34, (ref) v_u_35, (copy) v_u_172, (copy) p_u_165, (copy) p_u_166
				local v175 = false
				local v176 = false
				if p_u_167 == true then
					v175 = true
				else
					local v177 = p174.MetaData.ActiveSession
					local v178 = p174.MetaData.ForceLoadSession
					local v179 = p174.MetaData.SessionLoadCount
					if type(v177) == "table" then
						if v177[1] == v_u_34 then
							v175 = v177[2] == v_u_35
						else
							v175 = false
						end
						if v175 then
							v175 = v179 == v_u_172
						end
					end
					if type(v178) == "table" then
						local v180
						if v178[1] == v_u_34 then
							v180 = v178[2] == v_u_35
						else
							v180 = false
						end
						v176 = not v180
					end
				end
				if v175 == true then
					if p_u_167 ~= true then
						local v181 = p174.GlobalUpdates[2]
						local v182 = p_u_165.GlobalUpdates
						local v183 = v182._pending_update_lock
						local v184 = v182._pending_update_clear
						for v185 = 1, #v181 do
							for _, v186 in ipairs(v183) do
								if v181[v185][1] == v186 then
									v181[v185][3] = true
									break
								end
							end
						end
						for _, v187 in ipairs(v184) do
							for v188 = 1, #v181 do
								if v181[v188][1] == v187 and v181[v188][3] == true then
									table.remove(v181, v188)
									break
								end
							end
						end
					end
					p174.Data = p_u_165.Data
					p174.RobloxMetaData = p_u_165.RobloxMetaData
					p174.UserIds = p_u_165.UserIds
					if p_u_167 == true then
						p174.MetaData = p_u_165.MetaData
						p174.MetaData.ActiveSession = nil
						p174.MetaData.ForceLoadSession = nil
						p174.GlobalUpdates = p_u_165.GlobalUpdates._updates_latest
					else
						p174.MetaData.MetaTags = p_u_165.MetaData.MetaTags
						p174.MetaData.LastUpdate = os.time()
						if p_u_166 == true or v176 == true then
							p174.MetaData.ActiveSession = nil
							return
						end
					end
				end
			end
		}
		local v190, v191 = v_u_142(p_u_165._profile_store, p_u_165._profile_key, v189, p_u_165._is_user_mock)
		if v190 == nil or v191 == nil then
			if v173 == true then
				task.wait()
			end
		else
			if p_u_167 == true then
				break
			end
			p_u_165.KeyInfo = v191
			local v192 = p_u_165.GlobalUpdates
			local v193 = v192._updates_latest
			local v194 = v190.GlobalUpdates
			v192._updates_latest = v194
			local v195 = p_u_165.MetaData
			local v196 = v190.MetaData
			v173 = false
			for v197 in pairs(v_u_1.MetaTagsUpdatedValues) do
				v195[v197] = v196[v197]
			end
			v195.MetaTagsLatest = v196.MetaTags
			local v198 = v190.MetaData.ActiveSession
			local v199 = v190.MetaData.SessionLoadCount
			local v200
			if type(v198) == "table" then
				if v198[1] == v_u_34 then
					v200 = v198[2] == v_u_35
				else
					v200 = false
				end
				if v200 then
					v200 = v199 == v_u_172
				end
			else
				v200 = false
			end
			local v201 = p_u_165:IsActive()
			if v200 == true then
				if v201 == true then
					v_u_164(p_u_165, v193, v194)
				end
			else
				if v201 == true then
					v_u_150(p_u_165)
				end
				v_u_70(p_u_165._profile_store._profile_store_lookup, p_u_165._profile_key)
				if p_u_165._hop_ready == false then
					p_u_165._hop_ready = true
					p_u_165._hop_ready_listeners:Fire()
				end
			end
			p_u_165.MetaTagsUpdated:Fire(p_u_165.MetaData.MetaTagsLatest)
			p_u_165.KeyInfoUpdated:Fire(v191)
		end
	end
	v_u_40 = v_u_40 - 1
end
local v_u_203 = {}
v_u_203.__index = v_u_203
function v_u_203.GetActiveUpdates(p204)
	local v205 = {}
	for _, v206 in ipairs(p204._updates_latest[2]) do
		if v206[3] == false then
			local v207 = false
			if p204._pending_update_lock ~= nil then
				for _, v208 in ipairs(p204._pending_update_lock) do
					if v206[1] == v208 then
						v207 = true
						break
					end
				end
			end
			if v207 == false then
				local v209 = { v206[1], v206[4] }
				table.insert(v205, v209)
			end
		end
	end
	return v205
end
function v_u_203.GetLockedUpdates(p210)
	local v211 = {}
	for _, v212 in ipairs(p210._updates_latest[2]) do
		if v212[3] == true then
			local v213 = false
			if p210._pending_update_clear ~= nil then
				for _, v214 in ipairs(p210._pending_update_clear) do
					if v212[1] == v214 then
						v213 = true
						break
					end
				end
			end
			if v213 == false then
				local v215 = { v212[1], v212[4] }
				table.insert(v211, v215)
			end
		end
	end
	return v211
end
function v_u_203.ListenToNewActiveUpdate(p216, p217)
	if type(p217) ~= "function" then
		error("[ProfileService]: Only a function can be set as listener in GlobalUpdates:ListenToNewActiveUpdate()")
	end
	local v218 = p216._profile
	if p216._update_handler_mode == true then
		error("[ProfileService]: Can\'t listen to new global updates in ProfileStore:GlobalUpdateProfileAsync()")
	elseif p216._new_active_update_listeners == nil then
		error("[ProfileService]: Can\'t listen to new global updates in view mode")
	elseif v218:IsActive() == false then
		return {
			["Disconnect"] = function() end
		}
	end
	return p216._new_active_update_listeners:Connect(p217)
end
function v_u_203.ListenToNewLockedUpdate(p219, p220)
	if type(p220) ~= "function" then
		error("[ProfileService]: Only a function can be set as listener in GlobalUpdates:ListenToNewLockedUpdate()")
	end
	local v221 = p219._profile
	if p219._update_handler_mode == true then
		error("[ProfileService]: Can\'t listen to new global updates in ProfileStore:GlobalUpdateProfileAsync()")
	elseif p219._new_locked_update_listeners == nil then
		error("[ProfileService]: Can\'t listen to new global updates in view mode")
	elseif v221:IsActive() == false then
		return {
			["Disconnect"] = function() end
		}
	end
	return p219._new_locked_update_listeners:Connect(p220)
end
function v_u_203.LockActiveUpdate(p222, p223)
	if type(p223) ~= "number" then
		error("[ProfileService]: Invalid update_id")
	end
	local v224 = p222._profile
	if p222._update_handler_mode == true then
		error("[ProfileService]: Can\'t lock active global updates in ProfileStore:GlobalUpdateProfileAsync()")
	elseif p222._pending_update_lock == nil then
		error("[ProfileService]: Can\'t lock active global updates in view mode")
	elseif v224:IsActive() == false then
		error("[ProfileService]: PROFILE EXPIRED - Can\'t lock active global updates")
	end
	local v225 = nil
	for _, v226 in ipairs(p222._updates_latest[2]) do
		if v226[1] == p223 then
			v225 = v226
			break
		end
	end
	if v225 == nil then
		error("[ProfileService]: Passed non-existant update_id")
	else
		local v227 = false
		for _, v228 in ipairs(p222._pending_update_lock) do
			if p223 == v228 then
				v227 = true
				break
			end
		end
		if v227 == false and v225[3] == false then
			local v229 = p222._pending_update_lock
			table.insert(v229, p223)
			return
		end
	end
end
function v_u_203.ClearLockedUpdate(p230, p231)
	if type(p231) ~= "number" then
		error("[ProfileService]: Invalid update_id")
	end
	local v232 = p230._profile
	if p230._update_handler_mode == true then
		error("[ProfileService]: Can\'t clear locked global updates in ProfileStore:GlobalUpdateProfileAsync()")
	elseif p230._pending_update_clear == nil then
		error("[ProfileService]: Can\'t clear locked global updates in view mode")
	elseif v232:IsActive() == false then
		error("[ProfileService]: PROFILE EXPIRED - Can\'t clear locked global updates")
	end
	local v233 = nil
	for _, v234 in ipairs(p230._updates_latest[2]) do
		if v234[1] == p231 then
			v233 = v234
			break
		end
	end
	if v233 == nil then
		error("[ProfileService]: Passed non-existant update_id")
	else
		local v235 = false
		for _, v236 in ipairs(p230._pending_update_clear) do
			if p231 == v236 then
				v235 = true
				break
			end
		end
		if v235 == false and v233[3] == true then
			local v237 = p230._pending_update_clear
			table.insert(v237, p231)
			return
		end
	end
end
function v_u_203.AddActiveUpdate(p238, p239)
	if type(p239) ~= "table" then
		error("[ProfileService]: Invalid update_data")
	end
	if p238._new_active_update_listeners == nil then
		if p238._update_handler_mode ~= true then
			error("[ProfileService]: Can\'t add active global updates in view mode; Use ProfileStore:GlobalUpdateProfileAsync()")
		end
	else
		error("[ProfileService]: Can\'t add active global updates in loaded Profile; Use ProfileStore:GlobalUpdateProfileAsync()")
	end
	local v240 = p238._updates_latest
	local v241 = v240[1] + 1
	v240[1] = v241
	local v242 = v240[2]
	table.insert(v242, {
		v241,
		1,
		false,
		p239
	})
end
function v_u_203.ChangeActiveUpdate(p243, p244, p245)
	if type(p244) ~= "number" then
		error("[ProfileService]: Invalid update_id")
	end
	if type(p245) ~= "table" then
		error("[ProfileService]: Invalid update_data")
	end
	if p243._new_active_update_listeners == nil then
		if p243._update_handler_mode ~= true then
			error("[ProfileService]: Can\'t change active global updates in view mode; Use ProfileStore:GlobalUpdateProfileAsync()")
		end
	else
		error("[ProfileService]: Can\'t change active global updates in loaded Profile; Use ProfileStore:GlobalUpdateProfileAsync()")
	end
	local v246 = p243._updates_latest
	local v247 = nil
	for _, v248 in ipairs(v246[2]) do
		if p244 == v248[1] then
			v247 = v248
			break
		end
	end
	if v247 == nil then
		error("[ProfileService]: Passed non-existant update_id")
	else
		if v247[3] == true then
			error("[ProfileService]: Can\'t change locked global update")
		end
		v247[2] = v247[2] + 1
		v247[4] = p245
	end
end
function v_u_203.ClearActiveUpdate(p249, p250)
	if type(p250) ~= "number" then
		error("[ProfileService]: Invalid update_id argument")
	end
	if p249._new_active_update_listeners == nil then
		if p249._update_handler_mode ~= true then
			error("[ProfileService]: Can\'t clear active global updates in view mode; Use ProfileStore:GlobalUpdateProfileAsync()")
		end
	else
		error("[ProfileService]: Can\'t clear active global updates in loaded Profile; Use ProfileStore:GlobalUpdateProfileAsync()")
	end
	local v251 = p249._updates_latest
	local v252 = nil
	local v253 = nil
	for v254, v255 in ipairs(v251[2]) do
		if p250 == v255[1] then
			v253 = v254
			v252 = v255
			break
		end
	end
	if v252 == nil then
		error("[ProfileService]: Passed non-existant update_id")
	else
		if v252[3] == true then
			error("[ProfileService]: Can\'t clear locked global update")
		end
		table.remove(v251[2], v253)
	end
end
local v_u_256 = {}
v_u_256.__index = v_u_256
function v_u_256.IsActive(p257)
	return (p257._is_user_mock == true and p257._profile_store._mock_loaded_profiles or p257._profile_store._loaded_profiles)[p257._profile_key] == p257
end
function v_u_256.GetMetaTag(p258, p259)
	if p258.MetaData == nil then
		return nil
	else
		return p258.MetaData.MetaTags[p259]
	end
end
function v_u_256.SetMetaTag(p260, p261, p262)
	if type(p261) == "string" then
		if string.len(p261) == 0 then
			error("[ProfileService]: Invalid tag_name")
		end
	else
		error("[ProfileService]: tag_name must be a string")
	end
	p260.MetaData.MetaTags[p261] = p262
end
function v_u_256.Reconcile(p263)
	-- upvalues: (copy) v_u_59
	v_u_59(p263.Data, p263._profile_store._profile_template)
end
function v_u_256.ListenToRelease(p264, p265)
	if type(p265) ~= "function" then
		error("[ProfileService]: Only a function can be set as listener in Profile:ListenToRelease()")
	end
	if p264._view_mode == true then
		return {
			["Disconnect"] = function() end
		}
	end
	if p264:IsActive() ~= false then
		return p264._release_listeners:Connect(p265)
	end
	local v266 = p264.MetaData.ActiveSession
	local v267, v268
	if v266 == nil then
		v267 = nil
		v268 = nil
	else
		v267 = v266[1]
		v268 = v266[2]
	end
	p265(v267, v268)
	return {
		["Disconnect"] = function() end
	}
end
function v_u_256.Save(p269)
	-- upvalues: (copy) v_u_48, (copy) v_u_30, (ref) v_u_36, (ref) v_u_37, (copy) v_u_202
	if p269._view_mode == true then
		error("[ProfileService]: Can\'t save Profile in view mode - Should you be calling :OverwriteAsync() instead?")
	end
	if p269:IsActive() == false then
		warn("[ProfileService]: Attempted saving an inactive profile " .. p269:Identify() .. "; Traceback:\n" .. debug.traceback())
	else
		local v270 = p269._profile_store._profile_store_lookup
		local v271 = p269._profile_key
		local v272 = v_u_48[v270]
		local v273
		if v272 == nil then
			v273 = true
		else
			local v274 = v272[v271]
			v273 = v274 == nil and true or #v274.Queue == 0
		end
		if v273 == true then
			local v275 = table.find(v_u_30, p269)
			if v275 ~= nil then
				table.remove(v_u_30, v275)
				if v275 < v_u_36 then
					v_u_36 = v_u_36 - 1
				end
				if v_u_30[v_u_36] == nil then
					v_u_36 = 1
				end
			end
			local v276 = v_u_30
			local v277 = v_u_36
			table.insert(v276, v277, p269)
			if #v_u_30 > 1 then
				v_u_36 = v_u_36 + 1
			elseif #v_u_30 == 1 then
				v_u_37 = os.clock()
			end
			task.spawn(v_u_202, p269)
		end
	end
end
function v_u_256.Release(p278)
	-- upvalues: (copy) v_u_202
	if p278._view_mode ~= true then
		if p278:IsActive() == true then
			task.spawn(v_u_202, p278, true)
		end
	end
end
function v_u_256.ListenToHopReady(p279, p280)
	if type(p280) ~= "function" then
		error("[ProfileService]: Only a function can be set as listener in Profile:ListenToHopReady()")
	end
	if p279._view_mode == true then
		return {
			["Disconnect"] = function() end
		}
	end
	if p279._hop_ready ~= true then
		return p279._hop_ready_listeners:Connect(p280)
	end
	task.spawn(p280)
	return {
		["Disconnect"] = function() end
	}
end
function v_u_256.AddUserId(p281, p282)
	-- upvalues: (ref) v_u_44
	if type(p282) == "number" and p282 % 1 == 0 then
		if p282 >= 0 or (p281._is_user_mock == true or v_u_44 == true) then
			if table.find(p281.UserIds, p282) == nil then
				local v283 = p281.UserIds
				table.insert(v283, p282)
			end
		end
	else
		warn("[ProfileService]: Invalid UserId argument for :AddUserId() (" .. tostring(p282) .. "); Traceback:\n" .. debug.traceback())
		return
	end
end
function v_u_256.RemoveUserId(p284, p285)
	if type(p285) == "number" and p285 % 1 == 0 then
		local v286 = table.find(p284.UserIds, p285)
		if v286 ~= nil then
			table.remove(p284.UserIds, v286)
		end
	else
		warn("[ProfileService]: Invalid UserId argument for :RemoveUserId() (" .. tostring(p285) .. "); Traceback:\n" .. debug.traceback())
	end
end
function v_u_256.Identify(p287)
	-- upvalues: (copy) v_u_63
	return v_u_63(p287._profile_store._profile_store_name, p287._profile_store._profile_store_scope, p287._profile_key)
end
function v_u_256.ClearGlobalUpdates(p288)
	-- upvalues: (copy) v_u_203
	if p288._view_mode ~= true then
		error("[ProfileService]: :ClearGlobalUpdates() can only be used in view mode")
	end
	local v289 = {
		["_updates_latest"] = {
			0,
			{}
		},
		["_profile"] = p288
	}
	local v290 = v_u_203
	setmetatable(v289, v290)
	p288.GlobalUpdates = v289
end
function v_u_256.OverwriteAsync(p291)
	-- upvalues: (copy) v_u_202
	if p291._view_mode ~= true then
		error("[ProfileService]: :OverwriteAsync() can only be used in view mode")
	end
	v_u_202(p291, nil, true)
end
local v_u_292 = {}
v_u_292.__index = v_u_292
function v_u_292._MoveQueue(p293)
	while #p293._query_queue > 0 do
		local v294 = table.remove(p293._query_queue, 1)
		task.spawn(v294)
		if p293._is_query_yielded == true then
			break
		end
	end
end
function v_u_292.NextAsync(p_u_295, p296)
	if p_u_295._profile_store == nil then
		return nil
	end
	local v_u_297 = nil
	local v_u_298 = false
	local function v303()
		-- upvalues: (copy) p_u_295, (ref) v_u_298, (ref) v_u_297
		if p_u_295._query_failure == true then
			v_u_298 = true
			return
		elseif p_u_295._query_pages == nil then
			p_u_295._is_query_yielded = true
			task.spawn(function()
				-- upvalues: (ref) v_u_297, (ref) p_u_295, (ref) v_u_298
				v_u_297 = p_u_295:NextAsync(true)
				v_u_298 = true
			end)
			local v299, v300 = pcall(function()
				-- upvalues: (ref) p_u_295
				p_u_295._query_pages = p_u_295._profile_store._global_data_store:ListVersionsAsync(p_u_295._profile_key, p_u_295._sort_direction, p_u_295._min_date, p_u_295._max_date)
				p_u_295._query_index = 0
			end)
			if v299 == false or p_u_295._query_pages == nil then
				warn("[ProfileService]: Version query fail - " .. tostring(v300))
				p_u_295._query_failure = true
			end
			p_u_295._is_query_yielded = false
			p_u_295:_MoveQueue()
			return
		else
			local v301 = p_u_295._query_pages:GetCurrentPage()[p_u_295._query_index + 1]
			if p_u_295._query_pages.IsFinished == true and v301 == nil then
				v_u_298 = true
				return
			elseif v301 == nil then
				p_u_295._is_query_yielded = true
				task.spawn(function()
					-- upvalues: (ref) v_u_297, (ref) p_u_295, (ref) v_u_298
					v_u_297 = p_u_295:NextAsync(true)
					v_u_298 = true
				end)
				if pcall(function()
					-- upvalues: (ref) p_u_295
					p_u_295._query_pages:AdvanceToNextPageAsync()
					p_u_295._query_index = 0
				end) == false or #p_u_295._query_pages:GetCurrentPage() == 0 then
					p_u_295._query_failure = true
				end
				p_u_295._is_query_yielded = false
				p_u_295:_MoveQueue()
			else
				local v302 = p_u_295
				v302._query_index = v302._query_index + 1
				v_u_297 = p_u_295._profile_store:ViewProfileAsync(p_u_295._profile_key, v301.Version)
				v_u_298 = true
			end
		end
	end
	local v304
	if p_u_295._is_query_yielded == false then
		v303()
		v304 = v_u_297
	elseif p296 == true then
		local v305 = p_u_295._query_queue
		table.insert(v305, 1, v303)
		v304 = v_u_297
	else
		local v306 = p_u_295._query_queue
		table.insert(v306, v303)
		v304 = v_u_297
	end
	while v_u_298 == false do
		task.wait()
	end
	return v304
end
local v_u_307 = {}
v_u_307.__index = v_u_307
function v_u_307.LoadProfileAsync(p_u_308, p309, p310, p311)
	-- upvalues: (copy) v_u_28, (copy) v_u_47, (copy) v_u_29, (ref) v_u_39, (ref) v_u_38, (copy) v_u_142, (copy) v_u_34, (copy) v_u_35, (copy) v_u_1, (copy) v_u_53, (ref) v_u_27, (copy) v_u_203, (copy) v_u_256, (copy) v_u_30, (ref) v_u_36, (ref) v_u_37, (copy) v_u_202
	local v312 = p310 or "ForceLoad"
	if p_u_308._profile_template == nil then
		error("[ProfileService]: Profile template not set - ProfileStore:LoadProfileAsync() locked for this ProfileStore")
	end
	if type(p309) == "string" then
		if string.len(p309) == 0 then
			error("[ProfileService]: Invalid profile_key")
		end
	else
		error("[ProfileService]: profile_key must be a string")
	end
	if type(v312) ~= "function" and (v312 ~= "ForceLoad" and v312 ~= "Steal") then
		error("[ProfileService]: Invalid not_released_handler")
	end
	if v_u_28.ServiceLocked == true then
		return nil
	end
	while p_u_308._is_pending == true do
		task.wait()
	end
	local v313 = p311 == v_u_47
	for _, v314 in ipairs(v_u_29) do
		if v314._profile_store_lookup == p_u_308._profile_store_lookup and (v313 == true and v314._mock_loaded_profiles or v314._loaded_profiles)[p309] ~= nil then
			local v315 = error
			local v316 = p_u_308._profile_store_name
			local v317 = p_u_308._profile_store_scope
			v315("[ProfileService]: Profile " .. string.format("[Store:\"%s\";%sKey:\"%s\"]", v316, v317 == nil and "" or (string.format("Scope:\"%s\";", v317) or ""), p309) .. " is already loaded in this session")
		end
	end
	v_u_39 = v_u_39 + 1
	local v318 = v312 == "ForceLoad"
	local v319 = 0
	local v_u_320 = v318
	local v_u_321 = false
	local v_u_322
	if v312 == "Steal" then
		v_u_322 = true
	else
		v_u_322 = false
	end
	while v_u_28.ServiceLocked == false do
		local v323 = v313 == true and p_u_308._mock_profile_load_jobs or p_u_308._profile_load_jobs
		local v324 = v_u_38 + 1
		v_u_38 = v324
		local v325 = v323[p309]
		local v326, v327
		if v325 == nil then
			local v328 = { v324, nil }
			v323[p309] = v328
			local v343 = {
				["ExistingProfileHandle"] = function(p329)
					-- upvalues: (ref) v_u_28, (ref) v_u_34, (ref) v_u_35, (ref) v_u_1, (ref) v_u_321, (ref) v_u_322, (ref) v_u_320
					if v_u_28.ServiceLocked == false then
						local v330 = p329.MetaData.ActiveSession
						local v331 = p329.MetaData.ForceLoadSession
						if v330 == nil then
							local v332 = { v_u_34, v_u_35 }
							p329.MetaData.ActiveSession = v332
							p329.MetaData.ForceLoadSession = nil
							return
						end
						if type(v330) == "table" then
							local v333
							if v330[1] == v_u_34 then
								v333 = v330[2] == v_u_35
							else
								v333 = false
							end
							if v333 == false then
								local v334 = p329.MetaData.LastUpdate
								if v334 ~= nil and os.time() - v334 > v_u_1.AssumeDeadSessionLock then
									local v335 = { v_u_34, v_u_35 }
									p329.MetaData.ActiveSession = v335
									p329.MetaData.ForceLoadSession = nil
									return
								end
								if v_u_321 == true or v_u_322 == true then
									local v336
									if v331 == nil or v331[1] ~= v_u_34 then
										v336 = false
									else
										v336 = v331[2] == v_u_35
									end
									if v336 == true or v_u_322 == true then
										local v337 = { v_u_34, v_u_35 }
										p329.MetaData.ActiveSession = v337
										p329.MetaData.ForceLoadSession = nil
										return
									end
								elseif v_u_320 == true then
									local v338 = { v_u_34, v_u_35 }
									p329.MetaData.ForceLoadSession = v338
									return
								end
							else
								p329.MetaData.ForceLoadSession = nil
							end
						end
					end
				end,
				["MissingProfileHandle"] = function(p339)
					-- upvalues: (ref) v_u_53, (copy) p_u_308, (ref) v_u_34, (ref) v_u_35
					p339.Data = v_u_53(p_u_308._profile_template)
					p339.MetaData = {
						["ProfileCreateTime"] = os.time(),
						["SessionLoadCount"] = 0,
						["ActiveSession"] = { v_u_34, v_u_35 },
						["ForceLoadSession"] = nil,
						["MetaTags"] = {}
					}
				end,
				["EditProfile"] = function(p340)
					-- upvalues: (ref) v_u_28, (ref) v_u_34, (ref) v_u_35
					if v_u_28.ServiceLocked == false then
						local v341 = p340.MetaData.ActiveSession
						if v341 ~= nil then
							local v342
							if v341[1] == v_u_34 then
								v342 = v341[2] == v_u_35
							else
								v342 = false
							end
							if v342 == true then
								p340.MetaData.SessionLoadCount = p340.MetaData.SessionLoadCount + 1
								p340.MetaData.LastUpdate = os.time()
							end
						end
					end
				end
			}
			v328[2] = table.pack(v_u_142(p_u_308, p309, v343, v313))
			if v328[1] ~= v324 then
				v_u_39 = v_u_39 - 1
				return nil
			end
			local v344 = v328[2]
			v326, v327 = table.unpack(v344)
			v323[p309] = nil
		else
			v325[1] = v324
			while v325[2] == nil do
				task.wait()
			end
			if v325[1] ~= v324 then
				v_u_39 = v_u_39 - 1
				return nil
			end
			local v345 = v325[2]
			v326, v327 = table.unpack(v345)
			v323[p309] = nil
		end
		if v326 == nil or v327 == nil then
			task.wait()
		else
			local v346 = v326.MetaData.ActiveSession
			if type(v346) ~= "table" then
				v_u_39 = v_u_39 - 1
				return nil
			end
			local v347
			if v346[1] == v_u_34 then
				v347 = v346[2] == v_u_35
			else
				v347 = false
			end
			if v347 == true then
				v326.MetaData.MetaTagsLatest = v_u_53(v326.MetaData.MetaTags)
				local v348 = {
					["_updates_latest"] = v326.GlobalUpdates,
					["_pending_update_lock"] = {},
					["_pending_update_clear"] = {},
					["_new_active_update_listeners"] = v_u_27.NewScriptSignal(),
					["_new_locked_update_listeners"] = v_u_27.NewScriptSignal(),
					["_profile"] = nil
				}
				local v349 = v_u_203
				setmetatable(v348, v349)
				local v350 = {
					["Data"] = v326.Data,
					["MetaData"] = v326.MetaData,
					["MetaTagsUpdated"] = v_u_27.NewScriptSignal(),
					["RobloxMetaData"] = v326.RobloxMetaData or {},
					["UserIds"] = v326.UserIds or {},
					["KeyInfo"] = v327,
					["KeyInfoUpdated"] = v_u_27.NewScriptSignal(),
					["GlobalUpdates"] = v348,
					["_profile_store"] = p_u_308,
					["_profile_key"] = p309,
					["_release_listeners"] = v_u_27.NewScriptSignal(),
					["_hop_ready_listeners"] = v_u_27.NewScriptSignal(),
					["_hop_ready"] = false,
					["_load_timestamp"] = os.clock(),
					["_is_user_mock"] = v313
				}
				local v351 = v_u_256
				setmetatable(v350, v351)
				v348._profile = v350
				if next(p_u_308._loaded_profiles) == nil and next(p_u_308._mock_loaded_profiles) == nil then
					local v352 = v_u_29
					table.insert(v352, p_u_308)
				end
				if v313 == true then
					p_u_308._mock_loaded_profiles[p309] = v350
				else
					p_u_308._loaded_profiles[p309] = v350
				end
				local v353 = v_u_30
				local v354 = v_u_36
				table.insert(v353, v354, v350)
				if #v_u_30 > 1 then
					v_u_36 = v_u_36 + 1
				elseif #v_u_30 == 1 then
					v_u_37 = os.clock()
				end
				if v_u_28.ServiceLocked == true then
					v_u_202(v350, true)
					v350 = nil
				end
				v_u_39 = v_u_39 - 1
				return v350
			end
			local v355
			if v318 == true then
				local v356 = v326.MetaData.ForceLoadSession
				local v357
				if v356 == nil or v356[1] ~= v_u_34 then
					v357 = false
				else
					v357 = v356[2] == v_u_35
				end
				if v357 ~= true then
					v_u_39 = v_u_39 - 1
					return nil
				end
				if v_u_320 == false then
					v319 = v319 + 1
					if v319 == v_u_1.ForceLoadMaxSteps then
						local v358 = true
						v_u_321 = v358
					end
				end
				task.wait()
				v355 = false
				v_u_320 = v355
			elseif v_u_322 == true then
				task.wait()
			else
				local v359 = v312(v346[1], v346[2])
				if v359 == "Repeat" then
					task.wait()
				else
					if v359 == "Cancel" then
						v_u_39 = v_u_39 - 1
						return nil
					end
					if v359 == "ForceLoad" then
						v318 = true
						v355 = true
						task.wait()
						v_u_320 = v355
					elseif v359 == "Steal" then
						local v360 = true
						task.wait()
						v_u_322 = v360
					else
						local v361 = error
						local v362 = tostring(v359)
						local v363 = type(v359)
						local v364 = p_u_308._profile_store_name
						local v365 = p_u_308._profile_store_scope
						v361("[ProfileService]: Invalid return from not_released_handler (\"" .. v362 .. "\")(" .. v363 .. ");" .. "\n" .. string.format("[Store:\"%s\";%sKey:\"%s\"]", v364, v365 == nil and "" or (string.format("Scope:\"%s\";", v365) or ""), p309) .. " Traceback:\n" .. debug.traceback())
					end
				end
			end
		end
	end
	v_u_39 = v_u_39 - 1
	return nil
end
function v_u_307.GlobalUpdateProfileAsync(p366, p367, p_u_368, p369)
	-- upvalues: (copy) v_u_28, (copy) v_u_142, (copy) v_u_203, (copy) v_u_47, (copy) v_u_70
	if type(p367) ~= "string" or string.len(p367) == 0 then
		error("[ProfileService]: Invalid profile_key")
	end
	if type(p_u_368) ~= "function" then
		error("[ProfileService]: Invalid update_handler")
	end
	if v_u_28.ServiceLocked == true then
		return nil
	end
	while p366._is_pending == true do
		task.wait()
	end
	while v_u_28.ServiceLocked == false do
		local v373 = v_u_142(p366, p367, {
			["ExistingProfileHandle"] = nil,
			["MissingProfileHandle"] = nil,
			["EditProfile"] = function(p370)
				-- upvalues: (ref) v_u_203, (copy) p_u_368
				local v371 = {
					["_updates_latest"] = p370.GlobalUpdates,
					["_update_handler_mode"] = true
				}
				local v372 = v_u_203
				setmetatable(v371, v372)
				p_u_368(v371)
			end
		}, p369 == v_u_47)
		v_u_70(p366._profile_store_lookup, p367)
		if v373 ~= nil then
			local v374 = {
				["_updates_latest"] = v373.GlobalUpdates
			}
			local v375 = v_u_203
			setmetatable(v374, v375)
			return v374
		end
		task.wait()
	end
	return nil
end
function v_u_307.ViewProfileAsync(p_u_376, p377, p378, p379)
	-- upvalues: (copy) v_u_28, (copy) v_u_47, (ref) v_u_44, (copy) v_u_142, (copy) v_u_53, (copy) v_u_70, (copy) v_u_203, (ref) v_u_27, (copy) v_u_256
	if type(p377) ~= "string" or string.len(p377) == 0 then
		error("[ProfileService]: Invalid profile_key")
	end
	if v_u_28.ServiceLocked == true then
		return nil
	end
	while p_u_376._is_pending == true do
		task.wait()
	end
	if p378 ~= nil and (p379 == v_u_47 or v_u_44 == true) then
		return nil
	end
	while v_u_28.ServiceLocked == false do
		local v381, v382 = v_u_142(p_u_376, p377, {
			["ExistingProfileHandle"] = nil,
			["MissingProfileHandle"] = function(p380)
				-- upvalues: (ref) v_u_53, (copy) p_u_376
				p380.Data = v_u_53(p_u_376._profile_template)
				p380.MetaData = {
					["ProfileCreateTime"] = os.time(),
					["SessionLoadCount"] = 0,
					["ActiveSession"] = nil,
					["ForceLoadSession"] = nil,
					["MetaTags"] = {}
				}
			end,
			["EditProfile"] = nil
		}, p379 == v_u_47, true, p378)
		v_u_70(p_u_376._profile_store_lookup, p377)
		if v381 ~= nil then
			if v382 == nil then
				return nil
			end
			local v383 = {
				["_updates_latest"] = v381.GlobalUpdates,
				["_profile"] = nil
			}
			local v384 = v_u_203
			setmetatable(v383, v384)
			local v385 = {
				["Data"] = v381.Data,
				["MetaData"] = v381.MetaData,
				["MetaTagsUpdated"] = v_u_27.NewScriptSignal(),
				["RobloxMetaData"] = v381.RobloxMetaData or {},
				["UserIds"] = v381.UserIds or {},
				["KeyInfo"] = v382,
				["KeyInfoUpdated"] = v_u_27.NewScriptSignal(),
				["GlobalUpdates"] = v383,
				["_profile_store"] = p_u_376,
				["_profile_key"] = p377,
				["_view_mode"] = true,
				["_load_timestamp"] = os.clock()
			}
			local v386 = v_u_256
			setmetatable(v385, v386)
			v383._profile = v385
			return v385
		end
		task.wait()
	end
	return nil
end
function v_u_307.ProfileVersionQuery(p387, p388, p389, p390, p391, p392)
	-- upvalues: (copy) v_u_28, (copy) v_u_292, (copy) v_u_47, (ref) v_u_44
	if type(p388) ~= "string" or string.len(p388) == 0 then
		error("[ProfileService]: Invalid profile_key")
	end
	if v_u_28.ServiceLocked == true then
		local v393 = v_u_292
		return setmetatable({}, v393)
	end
	while p387._is_pending == true do
		task.wait()
	end
	if p392 == v_u_47 or v_u_44 == true then
		error("[ProfileService]: :ProfileVersionQuery() is not supported in mock mode")
	end
	if p389 ~= nil and (typeof(p389) ~= "EnumItem" or p389.EnumType ~= Enum.SortDirection) then
		error("[ProfileService]: Invalid sort_direction (" .. tostring(p389) .. ")")
	end
	if p390 ~= nil and (typeof(p390) ~= "DateTime" and typeof(p390) ~= "number") then
		error("[ProfileService]: Invalid min_date (" .. tostring(p390) .. ")")
	end
	if p391 ~= nil and (typeof(p391) ~= "DateTime" and typeof(p391) ~= "number") then
		error("[ProfileService]: Invalid max_date (" .. tostring(p391) .. ")")
	end
	if typeof(p390) == "DateTime" then
		p390 = p390.UnixTimestampMillis or p390
	end
	if typeof(p391) == "DateTime" then
		p391 = p391.UnixTimestampMillis or p391
	end
	local v394 = {
		["_profile_store"] = p387,
		["_profile_key"] = p388,
		["_sort_direction"] = p389,
		["_min_date"] = p390,
		["_max_date"] = p391,
		["_query_pages"] = nil,
		["_query_index"] = 0,
		["_query_failure"] = false,
		["_is_query_yielded"] = false,
		["_query_queue"] = {}
	}
	local v395 = v_u_292
	setmetatable(v394, v395)
	return v394
end
function v_u_307.WipeProfileAsync(p_u_396, p_u_397, p398)
	-- upvalues: (copy) v_u_28, (copy) v_u_47, (copy) v_u_46, (ref) v_u_44, (copy) v_u_45, (copy) v_u_70
	if type(p_u_397) ~= "string" or string.len(p_u_397) == 0 then
		error("[ProfileService]: Invalid profile_key")
	end
	if v_u_28.ServiceLocked == true then
		return false
	end
	while p_u_396._is_pending == true do
		task.wait()
	end
	local v399
	if p398 == v_u_47 then
		local v400 = v_u_46[p_u_396._profile_store_lookup]
		if v400 ~= nil then
			v400[p_u_397] = nil
		end
		task.wait()
		v399 = true
	elseif v_u_44 == true then
		local v401 = v_u_45[p_u_396._profile_store_lookup]
		if v401 ~= nil then
			v401[p_u_397] = nil
		end
		task.wait()
		v399 = true
	else
		v399 = pcall(function()
			-- upvalues: (copy) p_u_396, (copy) p_u_397
			p_u_396._global_data_store:RemoveAsync(p_u_397)
		end)
	end
	v_u_70(p_u_396._profile_store_lookup, p_u_397)
	return v399
end
function v_u_28.GetProfileStore(p402, p403)
	-- upvalues: (copy) v_u_47, (copy) v_u_307, (ref) v_u_43, (ref) v_u_44, (copy) v_u_32
	local v_u_404 = nil
	local v_u_405 = nil
	if type(p402) == "string" then
		v_u_404 = p402
	elseif type(p402) == "table" then
		v_u_404 = p402.Name
		v_u_405 = p402.Scope
	else
		error("[ProfileService]: Invalid or missing profile_store_index")
	end
	if v_u_404 == nil or type(v_u_404) ~= "string" then
		error("[ProfileService]: Missing or invalid \"Name\" parameter")
	elseif string.len(v_u_404) == 0 then
		error("[ProfileService]: ProfileStore name cannot be an empty string")
	end
	if v_u_405 ~= nil and (type(v_u_405) ~= "string" or string.len(v_u_405) == 0) then
		error("[ProfileService]: Invalid \"Scope\" parameter")
	end
	if type(p403) ~= "table" then
		error("[ProfileService]: Invalid profile_template")
	end
	local v_u_406 = nil
	v_u_406 = {
		["Mock"] = {
			["LoadProfileAsync"] = function(_, p407, p408)
				-- upvalues: (ref) v_u_406, (ref) v_u_47
				return v_u_406:LoadProfileAsync(p407, p408, v_u_47)
			end,
			["GlobalUpdateProfileAsync"] = function(_, p409, p410)
				-- upvalues: (ref) v_u_406, (ref) v_u_47
				return v_u_406:GlobalUpdateProfileAsync(p409, p410, v_u_47)
			end,
			["ViewProfileAsync"] = function(_, p411, p412)
				-- upvalues: (ref) v_u_406, (ref) v_u_47
				return v_u_406:ViewProfileAsync(p411, p412, v_u_47)
			end,
			["FindProfileVersionAsync"] = function(_, p413, p414, p415, p416)
				-- upvalues: (ref) v_u_406, (ref) v_u_47
				return v_u_406:FindProfileVersionAsync(p413, p414, p415, p416, v_u_47)
			end,
			["WipeProfileAsync"] = function(_, p417)
				-- upvalues: (ref) v_u_406, (ref) v_u_47
				return v_u_406:WipeProfileAsync(p417, v_u_47)
			end
		},
		["_profile_store_name"] = v_u_404,
		["_profile_store_scope"] = v_u_405,
		["_profile_store_lookup"] = v_u_404 .. "\0" .. (v_u_405 or ""),
		["_profile_template"] = p403,
		["_global_data_store"] = nil,
		["_loaded_profiles"] = {},
		["_profile_load_jobs"] = {},
		["_mock_loaded_profiles"] = {},
		["_mock_profile_load_jobs"] = {},
		["_is_pending"] = false
	}
	local v418 = v_u_307
	local v419 = v_u_406
	setmetatable(v419, v418)
	if v_u_43 == true then
		v_u_406._is_pending = true
		task.spawn(function()
			-- upvalues: (ref) v_u_43, (ref) v_u_44, (ref) v_u_406, (ref) v_u_32, (ref) v_u_404, (ref) v_u_405
			while v_u_43 == true do
				task.wait()
			end
			if v_u_44 == false then
				v_u_406._global_data_store = v_u_32:GetDataStore(v_u_404, v_u_405)
			end
			v_u_406._is_pending = false
		end)
	elseif v_u_44 == false then
		v_u_406._global_data_store = v_u_32:GetDataStore(v_u_404, v_u_405)
	end
	return v_u_406
end
function v_u_28.IsLive()
	-- upvalues: (ref) v_u_43, (ref) v_u_44
	while v_u_43 == true do
		task.wait()
	end
	local v420
	if v_u_44 == false then
		v420 = true
	else
		v420 = false
	end
	return v420
end
if v42 == true then
	v_u_43 = true
	task.spawn(function()
		-- upvalues: (copy) v_u_32, (ref) v_u_44, (copy) v_u_28, (ref) v_u_43
		local v421, v422 = pcall(function()
			-- upvalues: (ref) v_u_32
			v_u_32:GetDataStore("____PS"):SetAsync("____PS", os.time())
		end)
		local v423
		if v421 == false then
			v423 = string.find(v422, "ConnectFail", 1, true) ~= nil
		else
			v423 = false
		end
		if v423 == true then
			warn("[ProfileService]: No internet access - check your network connection")
		end
		if v421 == false and (string.find(v422, "403", 1, true) ~= nil or (string.find(v422, "must publish", 1, true) ~= nil or v423 == true)) then
			v_u_44 = true
			v_u_28._use_mock_data_store = true
			print("[ProfileService]: Roblox API services unavailable - data will not be saved")
		else
			print("[ProfileService]: Roblox API services available - data will be saved")
		end
		v_u_43 = false
	end)
end
v_u_33.Heartbeat:Connect(function()
	-- upvalues: (copy) v_u_30, (copy) v_u_1, (ref) v_u_37, (ref) v_u_36, (copy) v_u_202, (copy) v_u_28, (copy) v_u_31, (ref) v_u_41
	local v424 = #v_u_30
	if v424 > 0 then
		local v425 = v_u_1.AutoSaveProfiles / v424
		local v426 = os.clock()
		while v425 < v426 - v_u_37 do
			v_u_37 = v_u_37 + v425
			local v427 = v_u_30[v_u_36]
			if v426 - v427._load_timestamp < v_u_1.AutoSaveProfiles then
				v427 = nil
				for _ = 1, v424 - 1 do
					v_u_36 = v_u_36 + 1
					if v424 < v_u_36 then
						v_u_36 = 1
					end
					v427 = v_u_30[v_u_36]
					if v426 - v427._load_timestamp >= v_u_1.AutoSaveProfiles then
						break
					end
					v427 = nil
				end
			end
			v_u_36 = v_u_36 + 1
			if v424 < v_u_36 then
				v_u_36 = 1
			end
			if v427 ~= nil then
				task.spawn(v_u_202, v427)
			end
		end
	end
	if v_u_28.CriticalState == false then
		if #v_u_31 >= v_u_1.IssueCountForCriticalState then
			v_u_28.CriticalState = true
			v_u_28.CriticalStateSignal:Fire(true)
			v_u_41 = os.clock()
			warn("[ProfileService]: Entered critical state")
		end
	elseif #v_u_31 >= v_u_1.IssueCountForCriticalState then
		v_u_41 = os.clock()
	elseif os.clock() - v_u_41 > v_u_1.CriticalStateLast then
		v_u_28.CriticalState = false
		v_u_28.CriticalStateSignal:Fire(false)
		warn("[ProfileService]: Critical state ended")
	end
	while true do
		local v428 = v_u_31[1]
		if v428 == nil then
			break
		end
		if os.clock() - v428 <= v_u_1.IssueLast then
			return
		end
		table.remove(v_u_31, 1)
	end
end)
task.spawn(function()
	-- upvalues: (ref) v_u_43, (ref) v_u_27, (copy) v_u_28, (copy) v_u_30, (copy) v_u_202, (ref) v_u_39, (ref) v_u_40, (ref) v_u_44
	while v_u_43 == true do
		task.wait()
	end
	v_u_27.ConnectToOnClose(function()
		-- upvalues: (ref) v_u_28, (ref) v_u_30, (ref) v_u_202, (ref) v_u_39, (ref) v_u_40
		v_u_28.ServiceLocked = true
		local v429 = {}
		local v430 = 0
		for v431, v432 in ipairs(v_u_30) do
			v429[v431] = v432
		end
		for _, v_u_433 in ipairs(v429) do
			if v_u_433:IsActive() == true then
				local v_u_434 = v430 + 1
				task.spawn(function()
					-- upvalues: (ref) v_u_202, (copy) v_u_433, (ref) v_u_434
					v_u_202(v_u_433, true)
					v_u_434 = v_u_434 - 1
				end)
				v430 = v_u_434
			end
		end
		while v430 > 0 or (v_u_39 > 0 or v_u_40 > 0) do
			task.wait()
		end
	end, v_u_44 == false)
end)
return v_u_28