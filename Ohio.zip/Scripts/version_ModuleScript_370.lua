-- version (ModuleScript)
-- ReplicatedStorage > CmdrClient > Commands
-- Original

return {
	["Name"] = "version",
	["Args"] = {},
	["Description"] = "Shows the current version of Cmdr",
	["Group"] = "DefaultDebug",
	["Run"] = function()
		return ("Cmdr Version %s"):format("v1.12.0")
	end
}